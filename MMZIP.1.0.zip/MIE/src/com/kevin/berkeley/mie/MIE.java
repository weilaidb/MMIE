/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kevin.berkeley.mie;

/**
 *
 * @author John
 */
public class MIE {
    public static void main(String args[])
    {
        System.out.println("i coming here.................lala");
    }
}
